# ---------------------------------------
# -- Copyright (C) 2019 Astera Labs, Inc. 
# ---------------------------------------

# -- AUTO-GENERATED FILE. DO NOT MODIFY 

main_fmt_id_dict_fw_version_major = 1
main_fmt_id_dict_fw_version_minor = 20
main_fmt_id_dict_fw_build_number = 0

main_fmt_id_dict = {}

main_fmt_id_dict[1] = "[BL_IROM_MAIN] blk_len = %x"

main_fmt_id_dict[2] = "[BL_EEPROM_MAIN] blk_len = %x"

main_fmt_id_dict[3] = "[CL] path/pma/cfg load start"

main_fmt_id_dict[4] = "[CL] EEPROM load is done"

main_fmt_id_dict[5] = "[CL] Found a code block of type: %c"

main_fmt_id_dict[6] = "[BL] Wait for MODE pin high"

main_fmt_id_dict[7] = "[BL] MODE pin is high"

main_fmt_id_dict[8] = "MM start"

main_fmt_id_dict[9] = "%x ms: Skip MM self-reset. SCRATCHPAD5 = %x"

main_fmt_id_dict[10] = "%x ms: Performing on-demand MM program memory CRC check"

main_fmt_id_dict[11] = "%x ms: Completed on-demand MM program memory CRC check"

main_fmt_id_dict[12] = "Link PERST_N asserted low"

main_fmt_id_dict[13] = "%x ms: TIMEOUT: Non-Forwarding state has not progressed"

main_fmt_id_dict[14] = "Next data rate: Gen-%x"

main_fmt_id_dict[15] = "%x ms: rxX_data_en detected for side:%x, pid:%x, pma_ln:%x"

main_fmt_id_dict[16] = "Boot load failed: g_eeprom_ld_stat: %x, main: %x"

main_fmt_id_dict[17] = "BIFURC = %c"

main_fmt_id_dict[18] = "ARB CFG = %c"

main_fmt_id_dict[19] = "QS before intr_reg1=%x, intr_reg0=%x"

main_fmt_id_dict[20] = "QS after intr_reg1=%x, intr_reg0=%x"

main_fmt_id_dict[21] = "chip_pma_fast_sim"

main_fmt_id_dict[22] = "Releasing pipe, retimer, micro resets"

main_fmt_id_dict[23] = "Clk switched nicely :)"

main_fmt_id_dict[24] = "Abort nice mode clk switch"

main_fmt_id_dict[25] = "--> Nice Mode done"

main_fmt_id_dict[26] = "%x ms: ====WARNING: PhyStatus not asserted soon enough. Need to wait longer!===="

main_fmt_id_dict[27] = "fw_ate_service: srv = %x"

main_fmt_id_dict[28] = "chip_verify_main_micro_crc: Final self-calculated CRC: %x, EEPROM CRC: %x"

main_fmt_id_dict[29] = "FW_ERR: CINT_RD_SFR: No case for %x"

main_fmt_id_dict[30] = "Thermal over-temp (>= 120C)! Read Reg_0x424 for all-time max Tj ADC code. Current ADC code: %x"

main_fmt_id_dict[31] = "Intiating thermal shutdown."

main_fmt_id_dict[32] = "%x ms: New max DPLL:%x, side:%x, ln:%x"

main_fmt_id_dict[33] = "%x ms: New min DPLL:%x, side:%x, ln:%x"

main_fmt_id_dict[34] = "intr2 mc_mask: %x"

main_fmt_id_dict[35] = "PERST_N pin assertion"

main_fmt_id_dict[36] = "Hot un-plug detected. Removing Rx termination and forcing next_data_rate to GEN-1."

main_fmt_id_dict[37] = "%x ms: Entry to Recovery detected"

main_fmt_id_dict[38] = "%x ms: Detected Root Complex receiver(s)..."

main_fmt_id_dict[39] = "%x ms: Detected Endpoint receiver(s)..."

main_fmt_id_dict[40] = "Physical lane %x"

main_fmt_id_dict[41] = "SLC[%x]_HPI: INTR_TS1_LN_NON_PAD, %x"

main_fmt_id_dict[42] = "Switched to Normal path"

main_fmt_id_dict[43] = "DS switch to REFCLK before EQ P2 active"

main_fmt_id_dict[44] = "SLC[%x]_LPI: INTR_LPBK_ENTRY"

main_fmt_id_dict[45] = "SLC[%x]_LPI: INTR_LPBK_EXIT"

main_fmt_id_dict[46] = "lpbk"

main_fmt_id_dict[47] = "drate_id %c"

main_fmt_id_dict[48] = "cur_data_rate %c, lpbk_high_comm_rate[0] %c lpbk_high_comm_rate[1] %c"

main_fmt_id_dict[49] = "%x ms: Timer expired. Proceed with PERST."

main_fmt_id_dict[50] = "%x ms: Timer expired. Proceed with PERST de-assertion."

main_fmt_id_dict[51] = "%x ms: 1 second timer expired."

main_fmt_id_dict[52] = "Send PERST_N=0 to Link Paths"

main_fmt_id_dict[53] = "Switch to core clock"

main_fmt_id_dict[54] = "Assert pipe_lane_reset"

main_fmt_id_dict[55] = "Toggle PHY Reset"

main_fmt_id_dict[56] = "Switch clock source to PCLK"

main_fmt_id_dict[57] = "Send PERST_N=1 to Link Paths."

main_fmt_id_dict[58] = "%x ms: Switched to Bypass path"

main_fmt_id_dict[59] = "active_slc_bitmap = %x, %x, non_pad_slc_bitmap = %x, %x"

main_fmt_id_dict[60] = "wait ei_entry timeout"

main_fmt_id_dict[61] = "A pseudo port received HOT_RESET or DISABLE_LINK"

main_fmt_id_dict[62] = "Next data rate: Gen-%x, same_speed: %x"

main_fmt_id_dict[63] = "clear ei_entry"

main_fmt_id_dict[64] = "US switch to REFCLK before EQ P3 active"

main_fmt_id_dict[65] = "DS switch to low-latency clock before EQ P3 active"

main_fmt_id_dict[66] = "Switching to low-latency clock in EQ P3 active"

main_fmt_id_dict[67] = "%x ms: RX DETECT timeout"

main_fmt_id_dict[68] = "RX_VALID timeout"

main_fmt_id_dict[69] = "wait rdy_to_dsk:%c, rxdet_slc_msk:%c"

main_fmt_id_dict[70] = "Switching to low-latency clock before starting Deskew"

main_fmt_id_dict[71] = "Enable bypass mode"

main_fmt_id_dict[72] = "Disable bypass mode"

main_fmt_id_dict[73] = "state: %x, %x, ready_to_fwd: %x, %x"

main_fmt_id_dict[74] = "clr ready_to_deskew:%c, ready_to_fwd:%c"

main_fmt_id_dict[75] = "%x ms: LSM_LNK_STATE_RESET"

main_fmt_id_dict[76] = "%x ms: LSM_LNK_STATE_PERST_ENTRY"

main_fmt_id_dict[77] = "%x ms: LSM_LNK_STATE_PERST"

main_fmt_id_dict[78] = "%x ms: LSM_LNK_STATE_CHIP_PERST_WAIT_COMPLETE"

main_fmt_id_dict[79] = "%x ms: LSM_LNK_STATE_PERST_WAIT_COMPLETE"

main_fmt_id_dict[80] = "%x ms: LSM_LNK_STATE_RX_DETECT_DESKEW"

main_fmt_id_dict[81] = "%x ms: LSM_LNK_STATE_FORWARD"

main_fmt_id_dict[82] = "%x ms: LSM_LNK_STATE_EXEC_EQ_P2_ENTRY"

main_fmt_id_dict[83] = "%x ms: LSM_LNK_STATE_EXEC_EQ_P2_ACTIVE"

main_fmt_id_dict[84] = "%x ms: LSM_LNK_STATE_EXEC_EQ_P3_ACTIVE"

main_fmt_id_dict[85] = "%x ms: LSM_LNK_STATE_EXEC_EQ_P3_PASSIVE"

main_fmt_id_dict[86] = "%x ms: LSM_LNK_STATE_HOT_PLUG_SETTLE"

main_fmt_id_dict[87] = "%x ms: LSM_LNK_STATE_PERST_SETTLE"

main_fmt_id_dict[88] = "%x ms: UNKNOWN STATE"

main_fmt_id_dict[89] = "%x ms: LSM_LNK_PTH_STATE_IDLE"

main_fmt_id_dict[90] = "%x ms: LSM_LNK_PTH_STATE_WAIT_RX_DETECT"

main_fmt_id_dict[91] = "%x ms: LSM_LNK_PTH_STATE_RX_DETECT"

main_fmt_id_dict[92] = "%x ms: LSM_LNK_PTH_STATE_WAIT_READY_TO_DESKEW"

main_fmt_id_dict[93] = "%x ms: LSM_LNK_PTH_STATE_RX_VALID_ENTRY"

main_fmt_id_dict[94] = "%x ms: LSM_LNK_PTH_STATE_RX_VALID"

main_fmt_id_dict[95] = "%x ms: LSM_LNK_PTH_STATE_DESKEW"

main_fmt_id_dict[96] = "%x ms: LSM_LNK_PTH_STATE_WAIT_READY_TO_FWD"

main_fmt_id_dict[97] = "%x ms: LSM_LNK_PTH_STATE_FWD"

main_fmt_id_dict[98] = "%x ms: LSM_LNK_PTH_STATE_EI_ENTRY"

main_fmt_id_dict[99] = "%x ms: LSM_LNK_PTH_STATE_EI"

main_fmt_id_dict[100] = "%x ms: LSM_LNK_PTH_STATE_RATE_CHANGE"

main_fmt_id_dict[101] = "%x ms: LSM_LNK_PTH_STATE_WAIT_RATE_CHG_DONE"

main_fmt_id_dict[102] = "(1)===================== txX_ack:0, pid:%x ====================="

main_fmt_id_dict[103] = "[BOOT] self reset"

main_fmt_id_dict[104] = "[BOOT] main"

main_fmt_id_dict[105] = "[BOOT] init I2C master"

main_fmt_id_dict[106] = "[BOOT] Try one more time"

