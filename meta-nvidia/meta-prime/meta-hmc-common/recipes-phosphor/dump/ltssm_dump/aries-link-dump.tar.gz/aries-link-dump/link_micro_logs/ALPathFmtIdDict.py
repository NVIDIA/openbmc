# ---------------------------------------
# -- Copyright (C) 2019 Astera Labs, Inc. 
# ---------------------------------------

# -- AUTO-GENERATED FILE. DO NOT MODIFY 

path_fmt_id_dict_fw_version_major = 1
path_fmt_id_dict_fw_version_minor = 20
path_fmt_id_dict_fw_build_number = 0

path_fmt_id_dict = {}

path_fmt_id_dict[1] = "Detected Recovery.Equalization.Phase1 while in Bypass mode"

path_fmt_id_dict[2] = "Ln speed change. Common rates = %x"

path_fmt_id_dict[3] = "Rcvd Tx Precode Req: %x"

path_fmt_id_dict[4] = "Link master forced next state"

path_fmt_id_dict[5] = "ChipCfg.max_rate=%x"

path_fmt_id_dict[6] = "ChipCfg.sris_en=%x"

path_fmt_id_dict[7] = "ChipCfg.prt_orient_method=%x"

path_fmt_id_dict[8] = "PathCfg.cfg.prt_orient_cfg=%x"

path_fmt_id_dict[9] = "PathCfg.cfg.sel_deemph=%x"

path_fmt_id_dict[10] = "PathCfg.cfg.rx_imped_ctrl=%x"

path_fmt_id_dict[11] = "PathCfg.cfg.tx_compl_dis=%x"

path_fmt_id_dict[12] = "PathCfg.cfg.slave_lb_en=%x"

path_fmt_id_dict[13] = "PathCfg.cfg.pfp_en_gen5=%x"

path_fmt_id_dict[14] = "PathCfg.cfg.pfp_en_gen4=%x"

path_fmt_id_dict[15] = "PathCfg.cfg.pfp_en_gen3=%x"

path_fmt_id_dict[16] = "PathCfg.cfg.byp_en_gen5=%x"

path_fmt_id_dict[17] = "PathCfg.cfg.byp_en_gen4=%x"

path_fmt_id_dict[18] = "PathCfg.cfg.byp_en_gen3=%x"

path_fmt_id_dict[19] = "PathCfg.cfg.recov_clk_en_gen5=%x"

path_fmt_id_dict[20] = "PathCfg.cfg.recov_clk_en_gen4=%x"

path_fmt_id_dict[21] = "PathCfg.cfg.recov_clk_en_gen3=%x"

path_fmt_id_dict[22] = "PathCfg.cfg.eq_byp_highest_rate_sprtd=%x"

path_fmt_id_dict[23] = "PathCfg.cfg.no_eq_needed_sprtd=%x"

path_fmt_id_dict[24] = "PathCfg.cfg.mod_ts_sprtd=%x"

path_fmt_id_dict[25] = "PathCfg.cfg.tx_precode_req_gen5=%x"

path_fmt_id_dict[26] = "PathCfg.lane_cfg[%x].tx_preset_applied_gen5=%x"

path_fmt_id_dict[27] = "PathCfg.lane_cfg[%x].tx_preset_req_gen5=%x"

path_fmt_id_dict[28] = "PathCfg.lane_cfg[%x].tx_pre_applied_gen5=%x"

path_fmt_id_dict[29] = "PathCfg.lane_cfg[%x].tx_cur_applied_gen5=%x"

path_fmt_id_dict[30] = "PathCfg.lane_cfg[%x].tx_pst_applied_gen5=%x"

path_fmt_id_dict[31] = "PathCfg.lane_cfg[%x].tx_preset_applied_gen4=%x"

path_fmt_id_dict[32] = "PathCfg.lane_cfg[%x].tx_preset_req_gen4=%x"

path_fmt_id_dict[33] = "PathCfg.lane_cfg[%x].tx_pre_applied_gen4=%x"

path_fmt_id_dict[34] = "PathCfg.lane_cfg[%x].tx_cur_applied_gen4=%x"

path_fmt_id_dict[35] = "PathCfg.lane_cfg[%x].tx_pst_applied_gen4=%x"

path_fmt_id_dict[36] = "PathCfg.lane_cfg[%x].tx_preset_applied_gen3=%x"

path_fmt_id_dict[37] = "PathCfg.lane_cfg[%x].tx_preset_req_gen3=%x"

path_fmt_id_dict[38] = "PathCfg.lane_cfg[%x].tx_pre_applied_gen3=%x"

path_fmt_id_dict[39] = "PathCfg.lane_cfg[%x].tx_cur_applied_gen3=%x"

path_fmt_id_dict[40] = "PathCfg.lane_cfg[%x].tx_pst_applied_gen3=%x"

path_fmt_id_dict[41] = "PathCfg.lane_cfg[%x].tx_preset_eval_list_gen5=%x"

path_fmt_id_dict[42] = "PathCfg.lane_cfg[%x].tx_preset_eval_list_gen4=%x"

path_fmt_id_dict[43] = "PathCfg.lane_cfg[%x].tx_preset_eval_list_gen3=%x"

path_fmt_id_dict[44] = "Received CINTR_LNK_PTH_POL_DETECT_DONE from Link Master"

path_fmt_id_dict[45] = "Path PERST assert"

path_fmt_id_dict[46] = "Path PERST deassert"

path_fmt_id_dict[47] = "%x ms: Detected EI Entry. Blocking notification...."

path_fmt_id_dict[48] = "EI entry"

path_fmt_id_dict[49] = "Ln1 EI entry"

path_fmt_id_dict[50] = "New TS1_2C, EC=%x"

path_fmt_id_dict[51] = "Ln0/Ln1 Speed change before EI"

path_fmt_id_dict[52] = "Detected hot un-plug event"

path_fmt_id_dict[53] = "Ln0 EI entry"

path_fmt_id_dict[54] = "Ln%x SKP absence, send interrupt."

path_fmt_id_dict[55] = "Ln%x SKP absence"

path_fmt_id_dict[56] = "LN0: Applying PRESET request received on opposite path: %x"

path_fmt_id_dict[57] = "LN0: Applying COEFFICIENT request received on opposite path (pre,cur,pst): (%x,%x,%x)"

path_fmt_id_dict[58] = "LN0: current applied deemph: tx_pre=%x, tx_cur=%x, tx_pst=%x"

path_fmt_id_dict[59] = "LN1: Applying PRESET request received on opposite path: %x"

path_fmt_id_dict[60] = "LN1: current applied deemph: tx_pre=%x, tx_cur=%x, tx_pst=%x"

path_fmt_id_dict[61] = "LN1: Applying COEFFICIENT request received on opposite path (pre,cur,pst): (%x,%x,%x)"

path_fmt_id_dict[62] = "%x ms: PSM_IDLE"

path_fmt_id_dict[63] = "%x ms: PSM_RESET"

path_fmt_id_dict[64] = "%x ms: PSM_RESET_WAIT_COMPLETE"

path_fmt_id_dict[65] = "%x ms: PSM_DETECT"

path_fmt_id_dict[66] = "%x ms: PSM_DETECT_WAIT_RESULT"

path_fmt_id_dict[67] = "%x ms: PSM_DETECT_WAIT_COMPLETE"

path_fmt_id_dict[68] = "%x ms: PSM_WAIT_RX_VALID_ENTRY"

path_fmt_id_dict[69] = "%x ms: PSM_WAIT_RX_VALID"

path_fmt_id_dict[70] = "%x ms: PSM_CHECK_RX_POLARITY"

path_fmt_id_dict[71] = "%x ms: PSM_READY_TO_DESKEW_ENTRY"

path_fmt_id_dict[72] = "%x ms: PSM_READY_TO_DESKEW"

path_fmt_id_dict[73] = "%x ms: PSM_DESKEW_ENTRY"

path_fmt_id_dict[74] = "%x ms: PSM_DESKEW"

path_fmt_id_dict[75] = "%x ms: PSM_RATE_CHNG_WAIT_START"

path_fmt_id_dict[76] = "%x ms: PSM_RATE_CHNG_WAIT_COMPLETE"

path_fmt_id_dict[77] = "%x ms: PSM_RATE_CHNG_WAIT_INTERLOCK"

path_fmt_id_dict[78] = "%x ms: PSM_READY_TO_FWD_TS_ENTRY"

path_fmt_id_dict[79] = "%x ms: PSM_READY_TO_FWD_TS"

path_fmt_id_dict[80] = "%x ms: PSM_FWD_TS_ENTRY"

path_fmt_id_dict[81] = "%x ms: PSM_FWD_TS"

path_fmt_id_dict[82] = "%x ms: PSM_LOOPBACK_SLAVE_ENTRY"

path_fmt_id_dict[83] = "%x ms: PSM_LOOPBACK_SLAVE_EXIT"

path_fmt_id_dict[84] = "%x ms: PSM_EXEC_EQ_P2_ACT_ENTRY"

path_fmt_id_dict[85] = "%x ms: PSM_EXEC_EQ_P2_ACT_WAIT_START"

path_fmt_id_dict[86] = "%x ms: PSM_EXEC_EQ_P2_ACT_WAIT_EXEC_SW"

path_fmt_id_dict[87] = "%x ms: PSM_EXEC_EQ_P2_ACT"

path_fmt_id_dict[88] = "%x ms: PSM_EXEC_EQ_P2_PSV_ENTRY"

path_fmt_id_dict[89] = "%x ms: PSM_EXEC_EQ_P2_PSV"

path_fmt_id_dict[90] = "%x ms: PSM_EXEC_EQ_P3_ACT_ENTRY"

path_fmt_id_dict[91] = "%x ms: PSM_EXEC_EQ_P3_ACT_WAIT"

path_fmt_id_dict[92] = "%x ms: PSM_EXEC_EQ_P3_ACT"

path_fmt_id_dict[93] = "%x ms: PSM_EXEC_EQ_P3_PSV"

path_fmt_id_dict[94] = "%x ms: PSM_EXEC_EQ_WAIT_TO_ENTER_FWD"

path_fmt_id_dict[95] = "%x ms: PSM_EXEC_COMPLETE_FWD"

path_fmt_id_dict[96] = "%x ms: PSM_HOT_RESET"

path_fmt_id_dict[97] = "%x ms: PSM_DISABLE_LINK"

path_fmt_id_dict[98] = "%x ms: PSM_ERROR"

path_fmt_id_dict[99] = "%x ms: -EXCEEDED NUM_STATES-"

path_fmt_id_dict[100] = "===================== Rx ACK timed out ====================="

path_fmt_id_dict[101] = "Changing power state to P1"

path_fmt_id_dict[102] = "Current rate setting: GEN-%x"

path_fmt_id_dict[103] = "Changing rate to GEN1"

path_fmt_id_dict[104] = "Configured link_width: %x"

path_fmt_id_dict[105] = "Configured for max data rate: Gen-%c"

path_fmt_id_dict[106] = "Path is configured as DOWNSTREAM"

path_fmt_id_dict[107] = "Path is configured as UPSTREAM"

path_fmt_id_dict[108] = "RX Detect bypassed is not supported!"

path_fmt_id_dict[109] = "Changing power state to P0"

path_fmt_id_dict[110] = "%x ms: Ln0 RX_VALID=1, Ln1 RX_VALID=0"

path_fmt_id_dict[111] = "%x ms: Ln0 RX_VALID=0, Ln1 RX_VALID=1"

path_fmt_id_dict[112] = "Lane0 asic_in:  %x; Lane1 asic_in:  %x"

path_fmt_id_dict[113] = "Lane0 asic_out: %x; Lane1 asic_out: %x"

path_fmt_id_dict[114] = "Lane0 dpll:     %x; Lane1 dpll:     %x"

path_fmt_id_dict[115] = "Ln%c rx_eq_eval"

path_fmt_id_dict[116] = "Ln%c, FOM:%c"

path_fmt_id_dict[117] = "Ln%x rx_eq_eval"

path_fmt_id_dict[118] = "Lane0 Rx Valid: %x; Lane1 Rx Valid: %x"

path_fmt_id_dict[119] = "Lane0 asic_in: %x; Lane1 asic_in: %x"

path_fmt_id_dict[120] = "Ln%x detected INVERTED polarity"

path_fmt_id_dict[121] = "Ln%x detected NORMAL polarity"

path_fmt_id_dict[122] = "WARNING: No Deskew marker detected!"

path_fmt_id_dict[123] = "deskew_result: %x clocks (expect: <7 clocks)"

path_fmt_id_dict[124] = "Preset override applied: 0x%x"

path_fmt_id_dict[125] = "Writing mac_phy_txdeeph: 0x%x"

path_fmt_id_dict[126] = "LN%x: About to forward with tx_pre=%x, tx_cur=%x, tx_pst=%x"

path_fmt_id_dict[127] = "No EQ needed"

path_fmt_id_dict[128] = "Entered EQ P2 (Endpoint already in P3)"

path_fmt_id_dict[129] = "%x ms: RT_LinkUp. Captured Link#:%x Lane#:%x Lane#:%x"

path_fmt_id_dict[130] = "%x ms: Ln0 ei_inferred, send interrupt."

path_fmt_id_dict[131] = "%x ms: Ln1 ei_inferred, send interrupt."

path_fmt_id_dict[132] = "Hot Reset / Link Disable seen, waiting for 2ms, start"

path_fmt_id_dict[133] = "Hot Reset / Link Disable seen, waiting for 2ms, end"

path_fmt_id_dict[134] = "No speed change"

path_fmt_id_dict[135] = "Next rate: Gen-%c"

path_fmt_id_dict[136] = "Skipping P2 Active"

path_fmt_id_dict[137] = "%x ms: Ln%x, Preset:%x, FoM:00 (rx_valid=0). Redo eq_eval."

path_fmt_id_dict[138] = "%x ms: Ln%x, Preset:%x, FoM:%x"

path_fmt_id_dict[139] = "%x ms: Ln%x: Redo eq_eval"

path_fmt_id_dict[140] = "Entered EQ P3 with RC in Recovery.RcvrLock"

path_fmt_id_dict[141] = "Skipping P3 Active"

path_fmt_id_dict[142] = "Ln%x RxValid=0 dpll=%c"

path_fmt_id_dict[143] = "Ln%x RxValid=0 asic_in=%c asic_out=%c (will redo eq_eval)"

path_fmt_id_dict[144] = "Ln%x: Redo eq_eval"

path_fmt_id_dict[145] = "Enable PFP on switch to forwarding"

path_fmt_id_dict[146] = "LN%x: Finished EQ with tx_pre=0x%x, tx_cur=0x%x, tx_pst=0x%x"

path_fmt_id_dict[147] = "Hot Reset wait: 4 ms"

path_fmt_id_dict[148] = "Hot Reset wait: 64 ms"

path_fmt_id_dict[149] = "Link Disable wait: 4 ms"

path_fmt_id_dict[150] = "LN%x: OSM Tx settings: tx_pre=0x%x, tx_cur=0x%x, tx_pst=0x%x"

path_fmt_id_dict[151] = "Ignoring RC starting Preset request and applying %x on Upstream transmitters instead"

path_fmt_id_dict[152] = "Did not capture a starting Preset request. Use a default."

path_fmt_id_dict[153] = "Applying Preset %x for Gen-%x"

path_fmt_id_dict[154] = "Tx Precoding ON"

path_fmt_id_dict[155] = "Tx Precoding OFF"

path_fmt_id_dict[156] = "Rx Decoding ON"

path_fmt_id_dict[157] = "Rx Decoding OFF"

path_fmt_id_dict[158] = "============ Missing PhyStatus. May need to wait longer. ============"

path_fmt_id_dict[159] = "%x ms: Received request to enter low-latency mode on next trip through Recovery"

